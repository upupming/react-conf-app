export declare function initAlog(): void;
