declare const PerformanceTimingKeys: readonly ["updateSetStateTrigger", "updateDiffVdomStart", "updateDiffVdomEnd", "diffVdomStart", "diffVdomEnd", "packChangesStart", "packChangesEnd", "parseChangesStart", "parseChangesEnd", "patchChangesStart", "patchChangesEnd", "hydrateParseSnapshotStart", "hydrateParseSnapshotEnd", "mtsRenderStart", "mtsRenderEnd"];
declare const PerformanceTimingFlags: {
    readonly reactLynxHydrate: "react_lynx_hydrate";
};
declare const PipelineOrigins: {
    readonly reactLynxHydrate: "reactLynxHydrate";
    readonly updateTriggeredByBts: "updateTriggeredByBts";
};
type PipelineOrigin = typeof PipelineOrigins[keyof typeof PipelineOrigins];
/**
 * @deprecated used by old timing api(setState timing flag)
 */
declare const PerfSpecificKey = "__lynx_timing_flag";
declare let globalPipelineOptions: PipelineOptions | undefined;
/**
 * @deprecated used by old timing api(setState timing flag)
 */
declare function markTimingLegacy(key: typeof PerformanceTimingKeys[number], timingFlag_?: string): void;
declare function beginPipeline(needTimestamps: boolean, pipelineOrigin: PipelineOrigin, timingFlag?: string): void;
declare function setPipeline(pipeline: PipelineOptions | undefined): void;
declare function markTiming(timestampKey: typeof PerformanceTimingKeys[number], force?: boolean): void;
declare function initTimingAPI(): void;
export {};
