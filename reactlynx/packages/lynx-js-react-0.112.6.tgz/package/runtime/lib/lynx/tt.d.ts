import { runWithForce } from './runWithForce.js';
export { runWithForce };
declare function injectTt(): void;
declare function flushDelayedLifecycleEvents(): void;
export { injectTt, flushDelayedLifecycleEvents };
