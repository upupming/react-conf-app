export declare function setupLynxEnv(): void;
