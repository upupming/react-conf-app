/**
 * Load dynamic component from source. Designed to be used with `lazy`.
 * @param source - where dynamic component template.js locates
 * @returns
 * @public
 */
export declare const loadLazyBundle: <T extends {
    default: React.ComponentType<any>;
}>(source: string) => Promise<T>;
