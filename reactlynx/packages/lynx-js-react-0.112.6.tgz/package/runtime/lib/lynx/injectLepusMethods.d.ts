declare function injectLepusMethods(): void;
export {};
