export declare function loadDynamicJS<T>(url: string): Promise<T>;
export declare function __dynamicImport<T>(url: string, options?: {
    with?: {
        type?: 'component' | 'tsx' | 'jsx';
    };
}): Promise<T>;
