/**
 * Render Preact JSX + Components to an HTML string.
 * @param {VNode} vnode	JSX Element / VNode to render
 * @param {object} [context] Initial root context object
 */
export declare function renderToString(vnode: any, context: any): any[];
export declare const __OpBegin = 0;
export declare const __OpEnd = 1;
export declare const __OpAttr = 2;
export declare const __OpText = 3;
export default renderToString;
export declare const render: typeof renderToString;
export declare const renderToStaticMarkup: typeof renderToString;
