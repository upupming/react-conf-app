export declare const profileStart: typeof lynx.performance.profileStart;
export declare const profileEnd: typeof lynx.performance.profileEnd;
