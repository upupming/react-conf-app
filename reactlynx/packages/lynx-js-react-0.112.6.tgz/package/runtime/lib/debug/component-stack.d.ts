import type { VNode } from 'preact';
declare module 'preact' {
    interface Options {
        /** _root */
        __?(vnode: VNode, parent: any): void;
    }
}
interface PatchedVNode extends VNode {
    _owner?: PatchedVNode | null;
    __source?: {
        fileName: string;
        lineNumber: number;
    };
}
/**
 * Get human readable name of the component/dom node
 */
export declare function getDisplayName(vnode: PatchedVNode): string;
/**
 * Get the currently rendered `vnode`
 */
export declare function getCurrentVNode(): PatchedVNode | null;
/**
 * Return the component stack that was captured up to this point.
 */
export declare function getOwnerStack(vnode: PatchedVNode): string;
/**
 * Setup code to capture the component trace while rendering. Note that
 * we cannot simply traverse `vnode._parent` upwards, because we have some
 * debug messages for `this.setState` where the `vnode` is `undefined`.
 */
export declare function setupComponentStack(): void;
export {};
