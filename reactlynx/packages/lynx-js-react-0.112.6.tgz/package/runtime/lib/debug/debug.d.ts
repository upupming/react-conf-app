declare const logDebug: (...args: any[]) => void;
export {};
