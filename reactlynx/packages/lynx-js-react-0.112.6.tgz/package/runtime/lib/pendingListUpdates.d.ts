import type { ListUpdateInfo } from './listUpdateInfo.js';
export declare const __pendingListUpdates: {
    values: Record<number, ListUpdateInfo> | null;
    clear(id: number): void;
    clearAttachedLists(): void;
    flush(): void;
    flushWithId(id: number): void;
    runWithoutUpdates(cb: () => void): void;
};
