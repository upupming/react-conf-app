declare function updateWorkletEvent(): void;
export { updateWorkletEvent };
