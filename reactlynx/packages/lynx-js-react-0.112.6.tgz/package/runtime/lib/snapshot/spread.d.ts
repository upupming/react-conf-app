/**
 * Handles JSX spread operator in the snapshot system.
 *
 * Spread operators in JSX (e.g., <div {...props}>) are transformed into
 * optimized attribute updates at compile time, avoiding runtime object spreads.
 */
import type { BackgroundSnapshotInstance } from '../backgroundSnapshot.js';
import { SnapshotInstance } from '../snapshot.js';
declare function updateSpread(): void;
declare function transformSpread(snapshot: BackgroundSnapshotInstance | SnapshotInstance, index: number, spread: Record<string, unknown>): Record<string, unknown>;
export { transformSpread, updateSpread };
