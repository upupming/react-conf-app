import { SnapshotInstance } from '../snapshot.js';
declare function updateEvent(snapshot: SnapshotInstance, expIndex: number, _oldValue: any, elementIndex: number, eventType: string, eventName: string, spreadKey: string): void;
export { updateEvent };
