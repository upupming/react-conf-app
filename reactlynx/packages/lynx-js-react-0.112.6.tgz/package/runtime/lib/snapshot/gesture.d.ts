export declare function updateGesture(): void;
