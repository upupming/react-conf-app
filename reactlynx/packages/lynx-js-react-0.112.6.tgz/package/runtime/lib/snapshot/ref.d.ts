import { RefProxy } from '../lifecycle/ref/delay.js';
import type { SnapshotInstance } from '../snapshot.js';
type Ref = (((ref: RefProxy) => (() => void) | void) | {
    current: RefProxy | null;
}) & {
    _unmount?: (() => void) | void;
    __ref?: {
        value: number;
    };
};
declare function unref(snapshot: SnapshotInstance, recursive: boolean): void;
declare function applyRef(ref: Ref, value: null | [snapshotInstanceId: number]): void;
declare function transformRef(ref: unknown): Ref | null | undefined;
declare function applyQueuedRefs(): void;
declare function clearQueuedRefs(): void;
export {};
