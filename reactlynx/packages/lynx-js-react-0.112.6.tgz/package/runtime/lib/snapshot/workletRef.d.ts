import type { Element, Worklet, WorkletRefImpl } from '@lynx-js/react/worklet-runtime/bindings';
export declare function applyRefQueue(): void;
export declare function workletUnRef(value: Worklet | WorkletRefImpl<Element>): void;
export declare function updateWorkletRef(): void;
