import type { SnapshotInstance } from '../snapshot.js';
export declare function snapshotCreateList(pageId: number): FiberElement;
export declare function snapshotDestroyList(si: SnapshotInstance): void;
