/**
 * Core snapshot system that implements a compiler-hinted virtual DOM.
 *
 * Key components:
 * 1. {@link Snapshot}: Template definition generated at compile time
 * 2. {@link SnapshotInstance}: Runtime instance in the main thread
 * 3. {@link BackgroundSnapshotInstance}: Runtime instance in the background thread
 *
 * The system uses static analysis to identify dynamic parts and generate
 * optimized update instructions, avoiding full virtual DOM diffing.
 */
import type { Worklet, WorkletRefImpl } from '@lynx-js/react/worklet-runtime/bindings';
import type { BackgroundSnapshotInstance } from './backgroundSnapshot.js';
import { DynamicPartType } from './snapshot/dynamicPartType.js';
import type { PlatformInfo } from './snapshot/platformInfo.js';
/**
 * A snapshot definition that contains all the information needed to create and update elements
 * This is generated at compile time through static analysis of the JSX
 */
export interface Snapshot {
    create: null | ((ctx: SnapshotInstance) => FiberElement[]);
    setAttribute: null | ((ctx: SnapshotInstance, qualifiedName: string, value: string) => void);
    slot: [DynamicPartType, number][];
    isListHolder?: boolean;
    cssId?: number | undefined;
    entryName?: string | undefined;
    refAndSpreadIndexes?: number[] | null;
}
export declare let __page: FiberElement;
export declare let __pageId: number;
export declare function setupPage(page: FiberElement): void;
export declare function clearPage(): void;
export declare const __DynamicPartChildren_0: [DynamicPartType, number][];
export declare const __DynamicPartListChildren_0: [DynamicPartType, number][];
export declare const snapshotManager: {
    values: Map<string, Snapshot>;
};
export declare const snapshotInstanceManager: {
    nextId: number;
    values: Map<number, SnapshotInstance>;
    clear(): void;
};
export declare const backgroundSnapshotInstanceManager: {
    nextId: number;
    values: Map<number, BackgroundSnapshotInstance>;
    clear(): void;
    updateId(id: number, newId: number): void;
};
export declare function entryUniqID(uniqID: string, entryName?: string): string;
export declare function createSnapshot(uniqID: string, create: Snapshot['create'] | null, setAttribute: Snapshot['setAttribute'] | null, slot: Snapshot['slot'], cssId: number | undefined, entryName: string | undefined, refAndSpreadIndexes: number[] | null): string;
export interface WithChildren {
    childNodes: WithChildren[];
}
export declare function traverseSnapshotInstance<I extends WithChildren>(si: I, callback: (si: I) => void): void;
export interface SerializedSnapshotInstance {
    id: number;
    type: string;
    attributes?: Record<string, unknown> | undefined;
    children?: SerializedSnapshotInstance[] | undefined;
}
/**
 * The runtime instance of a {@link Snapshot} on the main thread that manages
 * the actual elements and handles updates to dynamic parts.
 *
 * This class is designed to be compatible with Preact's {@link ContainerNode}
 * interface for Preact's renderer to operate upon.
 */
export declare class SnapshotInstance {
    type: string;
    __id: number;
    __snapshot_def: Snapshot;
    __elements?: FiberElement[] | undefined;
    __element_root?: FiberElement | undefined;
    __attributes?: Record<string, string> | undefined;
    __current_slot_index: number;
    __worklet_ref_set?: Set<WorkletRefImpl<any> | Worklet>;
    __listItemPlatformInfo?: PlatformInfo;
    __extraProps?: Record<string, unknown> | undefined;
    constructor(type: string, id?: number);
    ensureElements(): void;
    unRenderElements(): void;
    takeElements(): SnapshotInstance;
    tearDown(): void;
    private __parent;
    private __firstChild;
    private __lastChild;
    private __previousSibling;
    private __nextSibling;
    get parentNode(): SnapshotInstance | null;
    get nextSibling(): SnapshotInstance | null;
    contains(child: SnapshotInstance): boolean;
    get childNodes(): SnapshotInstance[];
    __insertBefore(node: SnapshotInstance, beforeNode?: SnapshotInstance): void;
    __removeChild(node: SnapshotInstance): void;
    insertBefore(newNode: SnapshotInstance, existingNode?: SnapshotInstance): void;
    removeChild(child: SnapshotInstance): void;
    setAttribute(qualifiedName: string, value: string): void;
    toJSON(): Omit<SerializedSnapshotInstance, 'children'> & {
        children: SnapshotInstance[] | undefined;
    };
}
