declare class IndexMap<T> {
    protected lastIndex: number;
    protected indexMap: Map<number, T>;
    add(value: T): number;
    get(index: number): T | undefined;
    remove(index: number): void;
}
export { IndexMap };
