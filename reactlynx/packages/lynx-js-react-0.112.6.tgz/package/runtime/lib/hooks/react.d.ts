import { useCallback, useContext, useDebugValue, useErrorBoundary, useId, useImperativeHandle, useMemo, useReducer, useRef, useState } from 'preact/hooks';
import type { DependencyList, EffectCallback } from 'react';
/**
 * `useLayoutEffect` is now an alias of `useEffect`. Use `useEffect` instead.
 *
 * Accepts a function that contains imperative, possibly effectful code. The effects run after main thread dom update without blocking it.
 *
 * @param effect - Imperative function that can return a cleanup function
 * @param deps - If present, effect will only activate if the values in the list change (using ===).
 *
 * @public
 *
 * @deprecated `useLayoutEffect` in the background thread cannot offer the precise timing for reading layout information and synchronously re-render, which is different from React.
 */
declare function useLayoutEffect(effect: EffectCallback, deps?: DependencyList): void;
/**
 * Accepts a function that contains imperative, possibly effectful code.
 * The effects run after main thread dom update without blocking it.
 *
 * @param effect - Imperative function that can return a cleanup function
 * @param deps - If present, effect will only activate if the values in the list change (using ===).
 *
 * @public
 */
declare function useEffect(effect: EffectCallback, deps?: DependencyList): void;
export { useState, useReducer, useRef, useImperativeHandle, useLayoutEffect, useEffect, useCallback, useMemo, useContext, useDebugValue, useErrorBoundary, useId, };
