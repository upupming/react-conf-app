import type { SnapshotInstance } from './snapshot.js';
export declare const gSignMap: Record<number, Map<number, SnapshotInstance>>;
export declare const gRecycleMap: Record<number, Map<string, Map<number, SnapshotInstance>>>;
export declare function clearListGlobal(): void;
export declare function componentAtIndexFactory(ctx: SnapshotInstance[], hydrateFunction: (before: SnapshotInstance, after: SnapshotInstance) => void): [ComponentAtIndexCallback, ComponentAtIndexesCallback];
export declare function enqueueComponentFactory(): EnqueueComponentCallback;
