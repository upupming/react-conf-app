import type { FC } from 'react';
export declare function factory({ createElement, useMemo, Suspense, lazy }: typeof import('react'), loadLazyBundle: any): FC<{
    is: string;
}>;
