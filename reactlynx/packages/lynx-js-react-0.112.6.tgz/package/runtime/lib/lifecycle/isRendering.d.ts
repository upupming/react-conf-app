export declare const isRendering: {
    value: boolean;
};
