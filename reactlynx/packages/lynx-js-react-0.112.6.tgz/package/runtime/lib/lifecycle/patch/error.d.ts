export declare const ctxNotFoundType = "Lynx.Error.CtxNotFound";
export interface CtxNotFoundData {
    id: number;
}
export declare function sendCtxNotFoundEventToBackground(id: number): void;
export declare function reportCtxNotFound(data: CtxNotFoundData): void;
export declare function addCtxNotFoundEventListener(): void;
export declare function removeCtxNotFoundEventListener(): void;
