export declare let isMainThreadHydrating: boolean;
export declare function setMainThreadHydrating(isHydrating: boolean): void;
