/**
 * Defines the core patch operations for the snapshot system.
 * The patch operations are designed to be serializable and minimal, allowing
 * efficient transmission between threads and application to element tree.
 */
export declare const SnapshotOperation: {
    readonly CreateElement: 0;
    readonly InsertBefore: 1;
    readonly RemoveChild: 2;
    readonly SetAttribute: 3;
    readonly SetAttributes: 4;
    readonly DEV_ONLY_AddSnapshot: 100;
    readonly DEV_ONLY_RegisterWorklet: 101;
};
export declare const SnapshotOperationParams: Record<number, {
    name: string;
    params: string[];
}>;
export type SnapshotPatch = unknown[];
export declare let __globalSnapshotPatch: SnapshotPatch | undefined;
export declare function takeGlobalSnapshotPatch(): SnapshotPatch | undefined;
export declare function initGlobalSnapshotPatch(): void;
export declare function deinitGlobalSnapshotPatch(): void;
