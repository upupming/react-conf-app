declare function getReloadVersion(): number;
declare function increaseReloadVersion(): number;
export { getReloadVersion, increaseReloadVersion };
