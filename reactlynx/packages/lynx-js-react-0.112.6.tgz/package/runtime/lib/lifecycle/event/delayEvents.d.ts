declare let delayedEvents: [handlerName: string, data: unknown][] | undefined;
declare function delayedPublishEvent(handlerName: string, data: unknown): void;
export { delayedPublishEvent, delayedEvents };
