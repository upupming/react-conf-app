declare function renderMainThread(): void;
export { renderMainThread };
