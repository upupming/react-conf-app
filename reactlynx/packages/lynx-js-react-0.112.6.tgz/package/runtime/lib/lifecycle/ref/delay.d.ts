import type { NodesRef } from '@lynx-js/types';
/**
 * A flag to indicate whether UI operations should be delayed.
 * When set to true, UI operations will be queued in the `delayedUiOps` array
 * and executed later when `runDelayedUiOps` is called.
 * This is used before hydration to ensure UI operations are batched
 * and executed at the appropriate time.
 */
declare const shouldDelayUiOps: {
    value: boolean;
};
/**
 * Executes all delayed UI operations.
 */
declare function runDelayedUiOps(): void;
/**
 * A proxy class designed for managing and executing reference-based tasks.
 * It delays the execution of tasks until hydration is complete.
 */
declare class RefProxy {
    private readonly refAttr;
    private task;
    constructor(refAttr: [snapshotInstanceId: number]);
    private setTask;
    invoke(...args: Parameters<NodesRef['invoke']>): RefProxy;
    path(...args: Parameters<NodesRef['path']>): RefProxy;
    fields(...args: Parameters<NodesRef['fields']>): RefProxy;
    setNativeProps(...args: Parameters<NodesRef['setNativeProps']>): RefProxy;
    exec(): void;
}
export {};
