declare function destroyBackground(): void;
export { destroyBackground };
