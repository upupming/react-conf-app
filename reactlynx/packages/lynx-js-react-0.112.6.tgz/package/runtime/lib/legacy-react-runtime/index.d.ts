declare function __runInJS<T>(value: T): T | undefined | null;
export { ComponentFromReactRuntime as Component } from '../compat/lynxComponent.js';
export { ComponentFromReactRuntime as PureComponent } from '../compat/lynxComponent.js';
export { createContext } from 'preact';
export { lazy } from 'preact/compat';
export { useState, useReducer, useEffect, useMemo, useCallback } from '../hooks/react.js';
export { __runInJS };
