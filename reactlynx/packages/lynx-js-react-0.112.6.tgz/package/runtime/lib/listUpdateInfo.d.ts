import type { SnapshotInstance } from './snapshot.js';
export interface ListUpdateInfo {
    flush(): number | undefined;
    getAttachedListId(): number | undefined;
    onInsertBefore(newNode: SnapshotInstance, existingNode?: SnapshotInstance): void;
    onRemoveChild(child: SnapshotInstance): void;
    onSetAttribute(child: SnapshotInstance, attr: any): void;
}
interface InsertAction {
    position: number;
    type: string;
}
interface UpdateAction {
    from: number;
    to: number;
    type: string;
    flush: boolean;
}
interface ListOperations {
    insertAction: InsertAction[];
    removeAction: number[];
    updateAction: UpdateAction[];
}
export declare class ListUpdateInfoRecording implements ListUpdateInfo {
    private list;
    constructor(list: SnapshotInstance);
    flush(): undefined | number;
    getAttachedListId(): undefined | number;
    private oldChildNodes;
    private removeChild;
    private insertBefore;
    private appendChild;
    private platformInfoUpdate;
    onInsertBefore(newNode: SnapshotInstance, existingNode?: SnapshotInstance): void;
    onRemoveChild(child: SnapshotInstance): void;
    onSetAttribute(child: SnapshotInstance, attr: any): void;
    private __toAttribute;
    toJSON(): [ListOperations];
}
export {};
