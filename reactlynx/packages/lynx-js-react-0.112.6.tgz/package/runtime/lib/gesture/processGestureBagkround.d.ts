import type { GestureKind } from './types.js';
export declare function processGestureBackground(gesture: GestureKind): void;
