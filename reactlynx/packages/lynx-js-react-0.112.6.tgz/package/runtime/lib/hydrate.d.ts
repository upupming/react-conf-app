import type { SnapshotInstance } from './snapshot.js';
export interface DiffResult<K> {
    $$diff: true;
    i: Record<number, K>;
    r: number[];
    m: Record<number, number>;
}
export interface Typed {
    type: string;
}
export declare function isEmptyDiffResult<K>(diffResult: DiffResult<K>): boolean;
export declare function diffArrayLepus<A extends Typed, B extends Typed>(before: A[], after: B[], isSameType: (a: A, b: B) => boolean, onDiffChildren: (a: A, b: B, oldIndex: number, newIndex: number) => void): DiffResult<B>;
export declare function diffArrayAction<T, K>(before: T[], diffResult: DiffResult<K>, onInsert: (node: K, target: T | undefined) => T, onRemove: (node: T) => void, onMove: (node: T, target: T | undefined) => void): T[];
export interface HydrationOptions {
    skipUnRef?: boolean;
    swap?: Record<number, number>;
}
export declare function hydrate(before: SnapshotInstance, after: SnapshotInstance, options?: HydrationOptions): void;
