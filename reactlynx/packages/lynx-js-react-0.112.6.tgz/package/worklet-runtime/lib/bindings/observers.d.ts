import type { Worklet } from './types.js';
/**
 * This function must be called when a worklet context is updated.
 *
 * @param worklet - The worklet to be updated
 * @param oldWorklet - The old worklet context
 * @param isFirstScreen - Whether it is before the hydration is finished
 * @param element - The element
 */
export declare function onWorkletCtxUpdate(worklet: Worklet, oldWorklet: Worklet | null | undefined, isFirstScreen: boolean, element: ElementNode): void;
/**
 * This must be called when the hydration is finished.
 */
export declare function onHydrationFinished(): void;
