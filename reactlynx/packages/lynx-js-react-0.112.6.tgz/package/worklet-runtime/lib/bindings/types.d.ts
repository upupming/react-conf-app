import type { Element } from '../api/element.js';
export type { Element };
export type WorkletRefId = number;
export interface WorkletRefImpl<T> {
    _wvid: WorkletRefId;
    _initValue: T;
    _type: string;
    _lifecycleObserver?: unknown;
    current?: T;
}
export interface WorkletRef<T> {
    _wvid: WorkletRefId;
    current: T;
    [key: string]: unknown;
}
interface ClosureValueType_ extends Record<string, ClosureValueType> {
}
export type ClosureValueType = null | undefined | string | boolean | number | Worklet | WorkletRef<unknown> | Element | (((...args: unknown[]) => unknown) & {
    ctx?: ClosureValueType;
}) | ClosureValueType_ | ClosureValueType[];
export interface Worklet {
    _wkltId: string;
    _workletType?: string;
    _c?: Record<string, ClosureValueType>;
    _execId?: number;
    _jsFn?: Record<string, string>;
    _unmount?: () => void;
    [key: string]: ClosureValueType;
    _lepusWorkletHash?: string;
}
/**
 * @public
 */
export interface JsFnHandle {
    _jsFnId?: number;
    _fn?: (...args: unknown[]) => unknown;
    _execId?: number;
    _error?: string;
    _isFirstScreen?: boolean;
    /**
     * Stores an array of indexes of runOnBackground tasks that should be processed with a delay.
     * This is used before hydration.
     */
    _delayIndices?: number[];
}
