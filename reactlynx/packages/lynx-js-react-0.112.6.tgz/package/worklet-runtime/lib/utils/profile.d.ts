export declare function profile<Ret, Fn extends (...args: unknown[]) => Ret>(sliceName: string, f: Fn): Ret;
