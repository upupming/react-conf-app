export declare function isSdkVersionGt(major: number, minor: number): boolean;
