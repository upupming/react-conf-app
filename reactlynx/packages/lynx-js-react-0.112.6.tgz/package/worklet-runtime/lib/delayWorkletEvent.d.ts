import type { ClosureValueType, Worklet } from './bindings/types.js';
interface EventDelayImpl {
    _delayedWorkletParamsMap: Map<string, ClosureValueType[][]>;
    runDelayedWorklet(worklet: Worklet, element: ElementNode): void;
    clearDelayedWorklets(): void;
}
declare function initEventDelay(): EventDelayImpl;
declare function delayExecUntilJsReady(hash: string, params: ClosureValueType[]): void;
declare function runDelayedWorklet(worklet: Worklet, element: ElementNode): void;
declare function clearDelayedWorklets(): void;
export { type EventDelayImpl, initEventDelay, delayExecUntilJsReady, runDelayedWorklet, clearDelayedWorklets };
