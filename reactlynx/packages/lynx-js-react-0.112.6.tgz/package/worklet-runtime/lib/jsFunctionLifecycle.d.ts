/**
 * `JsFunctionLifecycleManager` monitors references to JS function handles to be called by `runOnBackground()`.
 * In JS context, functions to be called by `runOnBackground()` is referenced by `JsFnHandle`s and finally by `execId`.
 * When all `JsFnHandle`s in lepus are released, an event will be sent to JS context to de-ref the `execId`,
 * resulting a de-ref to the js function in JS context.
 */
declare class JsFunctionLifecycleManager {
    private execIdRefCount;
    private execIdSetToFire;
    private willFire;
    private registry?;
    constructor();
    addRef(execId: number, objToRef: object): void;
    removeRef(execId: number): void;
    fire(): void;
}
declare function isRunOnBackgroundEnabled(): boolean;
export { JsFunctionLifecycleManager, isRunOnBackgroundEnabled };
