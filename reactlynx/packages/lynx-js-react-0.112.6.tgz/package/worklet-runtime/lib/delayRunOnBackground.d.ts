import type { JsFnHandle } from './bindings/types.js';
interface Details {
    task: (fnId: number, execId: number) => void;
    jsFnHandle?: JsFnHandle;
}
interface RunOnBackgroundDelayImpl {
    delayedBackgroundFunctionArray: Details[];
    delayRunOnBackground(fnObj: JsFnHandle, fn: (fnId: number, execId: number) => void): void;
    runDelayedBackgroundFunctions(): void;
}
declare function initRunOnBackgroundDelay(): RunOnBackgroundDelayImpl;
export { type RunOnBackgroundDelayImpl, initRunOnBackgroundDelay };
