import type { ClosureValueType, Worklet } from './bindings/index.js';
export declare function runRunOnMainThreadTask(task: Worklet, params: ClosureValueType[], resolveId: number): void;
