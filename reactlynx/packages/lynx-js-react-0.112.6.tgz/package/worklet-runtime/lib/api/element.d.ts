import { Animation } from './animation/animation.js';
export declare function setShouldFlush(value: boolean): void;
export declare class Element {
    private readonly element;
    constructor(element: ElementNode);
    setAttribute(name: string, value: unknown): void;
    setStyleProperty(name: string, value: string): void;
    setStyleProperties(styles: Record<string, string>): void;
    getAttribute(attributeName: string): unknown;
    getAttributeNames(): string[];
    querySelector(selector: string): Element | null;
    querySelectorAll(selector: string): Element[];
    animate(keyframes: Record<string, number | string>[], options?: number | Record<string, number | string>): Animation;
    invoke(methodName: string, params?: Record<string, unknown>): Promise<unknown>;
    private flushElementTree;
}
