declare function initApiEnv(): void;
export { initApiEnv };
