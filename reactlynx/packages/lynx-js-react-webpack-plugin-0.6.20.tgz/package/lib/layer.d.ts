export declare const LAYERS: {
    readonly BACKGROUND: "react:background";
    readonly MAIN_THREAD: "react:main-thread";
};
