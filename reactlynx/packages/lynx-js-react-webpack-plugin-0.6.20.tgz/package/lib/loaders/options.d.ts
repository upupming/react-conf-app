import type { LoaderContext } from '@rspack/core';
import type { CompatVisitorConfig, DefineDceVisitorConfig, JsxTransformerConfig, ShakeVisitorConfig, TransformNodiffOptions } from '@lynx-js/react/transform';
/**
 * The options of the ReactLynx plugin.
 * @public
 */
export interface ReactLoaderOptions {
    /**
     * {@inheritdoc @lynx-js/react-rsbuild-plugin#PluginReactLynxOptions.compat}
     */
    compat?: CompatVisitorConfig | undefined;
    /**
     * {@inheritdoc @lynx-js/template-webpack-plugin#LynxTemplatePluginOptions.enableRemoveCSSScope}
     */
    enableRemoveCSSScope?: boolean | undefined;
    /**
     * {@inheritdoc @lynx-js/react-rsbuild-plugin#PluginReactLynxOptions.jsx}
     */
    jsx?: JsxTransformerConfig | undefined;
    /**
     * Enable the Fast Refresh for ReactLynx.
     */
    refresh?: boolean | undefined;
    /**
     * How main-thread code will be shaken.
     */
    shake?: ShakeVisitorConfig | undefined;
    /**
     * Like `define` in various bundlers, but this one happens at transform time, and a DCE pass will be performed.
     */
    defineDCE?: DefineDceVisitorConfig | undefined;
    /**
     * Generate inline source content in source-map.
     */
    inlineSourcesContent?: boolean | undefined;
}
export declare function getMainThreadTransformOptions(this: LoaderContext<ReactLoaderOptions>): TransformNodiffOptions;
export declare function getBackgroundTransformOptions(this: LoaderContext<ReactLoaderOptions>): TransformNodiffOptions;
