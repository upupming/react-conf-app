import type { LoaderContext } from '@rspack/core';
import type { ReactLoaderOptions } from './options.js';
declare function mainThreadLoader(this: LoaderContext<ReactLoaderOptions>, content: string): void;
export default mainThreadLoader;
