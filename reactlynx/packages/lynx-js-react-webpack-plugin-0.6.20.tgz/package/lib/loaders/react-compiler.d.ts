import type { LoaderContext } from '@rspack/core';
import type { ReactLoaderOptions } from './options.js';
declare function reactCompilerLoader(this: LoaderContext<ReactLoaderOptions>, content: string): Promise<void>;
export default reactCompilerLoader;
