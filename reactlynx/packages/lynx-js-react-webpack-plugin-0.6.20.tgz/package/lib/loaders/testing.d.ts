import type { LoaderContext } from '@rspack/core';
import type { ReactLoaderOptions } from './options.js';
declare function testingLoader(this: LoaderContext<ReactLoaderOptions>, content: string): void;
export default testingLoader;
