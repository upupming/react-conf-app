import type { RuntimeModule } from '@rspack/core';
type LynxProcessEvalResultRuntimeModule = new () => RuntimeModule;
export declare function createLynxProcessEvalResultRuntimeModule(webpack: typeof import('@rspack/core').rspack): LynxProcessEvalResultRuntimeModule;
export {};
